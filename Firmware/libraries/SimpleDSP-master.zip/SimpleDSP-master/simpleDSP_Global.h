/* begin simpleDSP_Global.h */
#ifndef _SIMPLEDSP_GLOBAL_H
#define _SIMPLEDSP_GLOBAL_H

typedef struct
{
    float real;
    float imag;
} COMPLEX;

#endif /* end simpleDSP_Global.h */
